# Handoff — identity, IA restructure, project vocabulary

Design changes to port into the implemented tracker. Written to be applied
selectively: each section is independent, and the "Do not port" list at the end
matters as much as the rest.

**Scoped to avoid:** table functionality, the Export → interactive HTML option,
and the Wigwag logo work. See [Leave alone](#leave-alone).

---

## 1. Identities

An identity is a named bundle: display label, email, state repo, signing key,
host token, bridge root. Email is the identity — it matches git's commit model,
so there is no separate mention/user layer.

**Projects belong to an identity.** This is the load-bearing change.

- Each project carries an `identityId`.
- The project switcher lists only the active identity's projects.
- Switching identity swaps the entire project set (snapshot the current
  project's state, restore the target's).
- Project counts shown anywhere are derived from the project list, never stored
  on the identity — otherwise they drift.

Why identity-first: it makes the relationship containment rather than
derivation. Nothing is inferred from paths or remotes, so there are no
match rules to explain, no per-project overrides, and no
"your git config disagrees" warnings. All three were designed and discarded
once identity became the outer scope.

### Identity pill

Top-right of the app bar, after a 1px divider. Person glyph + short org label
(`Personal`, `Northwind`, `Open source`) + caret.

- **Labels are org names, not initials.** Initials were tried and abandoned:
  every identity is the same human, so initials carry no signal. The
  organisation is what differs.
- Colour lives on a small dot per identity in the dropdown, not on an avatar
  square.
- Renders only when more than one identity exists.

### Identity dropdown

Three parts, in order:

1. Active identity — label, email, state repo, project count.
2. `SWITCH IDENTITY` list — each row shows label, then `<state repo> · N projects`,
   so containment is visible before you click.
3. A plain line: *"Switching reloads the project list and everything you write is
   attributed to that address."*
4. `Manage identities…`

### Settings › Identities panel

Slide-over, same anatomy as the project panel. One card per identity showing
state repo, project count, signing key, host token, bridge root. Badges for
`IN USE HERE` and `DEFAULT`; `Make default` action; `+ Add identity`.

Open question left unresolved: the host token probably belongs on each *source
connection* rather than on the identity, because the failure modes differ — a
wrong identity mis-attributes writes (fix: switch), an expired token stops one
source syncing (fix: re-auth that source). Putting them on one card implies
switching identity might fix a sync failure.

### Identity scope prefix on the title

    Personal / Delivery tracker ▾
    ^^^^^^^^^^                    non-interactive, 20px/400, grey

Separate from the pill and deliberately **not** a control — no hover state, no
caret, not clickable. All switching happens in the pill.

This arrangement failed twice as an interactive segment: a clickable identity
next to the title competes with it for rank and always loses, so it reads as a
weak thing wearing the leading position. As inert text it reads as scope.

Hidden when there is only one identity — a breadcrumb with one possible parent
is decoration.

Spacing: the separator owns the gap on both sides (10px each). Watch for a
negative margin on the title group cancelling the title's own left padding —
that is what makes the two gaps look uneven.

---

## 2. IA — two bars, one footer

Three tiers, split by scope.

| Tier | Scope | Contents |
|---|---|---|
| App bar (tinted, ~43px) | Application | Logo + wordmark · `Import project from file…` · divider · identity pill |
| Project bar (white, ~77px) | The open project | `Personal / Delivery tracker ▾` · `Project` · `Apply update…` · `↑ Share` |
| Footer (no rule) | The file | `Format v0.1.0 · Updated <ISO 8601> · { } View source` |

Tier heights differ deliberately, so hierarchy does not rest on tint alone.

**Filter is not an action.** It moved out of the button group and docks above
the table, left-aligned to the table's edge, 340px. It changes what you see,
not what exists; sitting between action buttons it acquired button semantics it
does not have.

**Nothing in either bar is filled.** Export/Share was the only solid button and
read as the app's primary action, which exporting is not.

---

## 3. Vocabulary — "project"

`milestone` → `project` everywhere, in copy *and* code (state keys, methods,
handlers). 172 occurrences in the prototype. Mixed vocabulary was doing more
damage than either word alone.

"Tracker" is reserved for the *source* systems a project draws from, so it
cannot also name the container: "this project pulls from three trackers."

### Button names

| Action | Label | Why |
|---|---|---|
| Adopt a project you were sent | `Import project from file…` | Identical label in the app bar and in `▾ Add project`, because it is the same operation. Two entry points is deliberate — new users need it findable. |
| Take in a newer version of this project | `Apply update…` | The common path is receiving an emailed file. "Apply" keeps the user as agent while presupposing the file came from someone else — and it is git's own word for taking in a change that arrived as a file rather than from a remote. Rejected: Import (implies new material), Pull (implies you fetched it), Ingest (pipeline jargon), Receive (passive). |
| Send this project out | `↑ Share` | Names the intent, not the mechanism. Pairs with `Apply update…` as the two halves of one loop. |

### Share menu

Round-trip formats only — anything someone can send back. Each item has a
sub-line:

- **Save project file…** — *A `.jsonl` anyone can apply as an update*
- **Copy to clipboard** — *Paste straight into an email or chat*
- **Save as interactive HTML…** — keep the existing option here. It qualifies
  as sharing: the recipient can make changes and send it back. `Apply update…`
  should eventually accept exported HTML as well as `.jsonl` — not now, but
  that is the reason it belongs in Share rather than Export.

**CSV moved out of Share** into an `EXPORT` section at the foot of the project
panel: *"A flat snapshot for spreadsheets. It can't be applied back as an update
— use Share for that."*

The dividing line is **can it come back?** JSONL and interactive HTML can, so
they are Share. CSV cannot — it is one-way and lossy — so it is Export.

Note the risk in the word "Share": in most software it means permissions and
collaborator lists. Wigwag has none by design, so menu copy must be explicit
about producing a file. `↑ Send` is the safer alternative if that still
overpromises.

---

## 4. The project panel

The `Project` button (was `Notes`) opens a slide-over holding **name, notes,
comments** — the project's own facts. Renamed from Notes because rename lives
here now and would have been unfindable under "Notes".

### Rename moved here, with friction

Clicking the title **opens this panel**; it no longer edits in place. The caret
still opens the switcher.

Name shows read-only with a `Rename…` link. Committing needs a deliberate Save
against this line:

> ⚠ This name is stored in the file. Everyone else will see it change the next
> time they load or receive an update.

**Why the friction:** the name is how everyone else finds the project. When
Alice receives Bob's update and Bob has renamed it, Alice can't match it to what
she has — a rename by one person costs everyone else recognition. That is
different from a destructive action (it is reversible); the resistance is there
because the cost lands on people who weren't in the room.

Rename is the only project-level action with friction. Everything else in the
panel is local until you Share.

Two adjacent targets, two destinations: put hover backgrounds on the title and
the caret **individually**, never on their shared wrapper — a group-level
highlight makes a 190px unit look like one control with one destination.

---

## 5. Smaller changes

- **Project dropdown anchors to the project name**, not the header row's left
  edge, so it stays put whatever the identity label's length.
- **Footer** — `Format v0.1.0 · Updated <ISO 8601> · { } View source`, middot
  separated, under the add-item bar, no rule above it. Dropped: filename and
  issue count.
- **Comment count chip removed** from the Project button.
- **Wordmark in Space Grotesk** (the logo face). Brand voice only — the UI face
  is unchanged.

### Bug fix worth porting

**Unvisited projects opened with the previous project's issues.** The
snapshot/restore had no empty-state fallback, so switching to a project never
opened before inherited whatever was on screen. This predates the identity work
and affects plain project switching too.

---

## Leave alone

- **Table functionality** — nothing here touches it.
- **Export → interactive HTML.** Keep it, and keep it in **Share** — see
  [Share menu](#share-menu). Recipients can edit it and send it back, so it is
  a round-trip format, not an export.
- **The Wigwag logo work.**

## Do not port

Prototype scaffolding, not design:

- `hint-placeholder-val` additions on popover conditionals — an artefact of how
  the prototype streams.
- `showIdentityLozenge` and `lozengeLabel` tweak props.
- The 880px page min-width — a blunt fix for header reflow in the prototype.

---

## Decisions taken and discarded

Worth knowing so they aren't relitigated:

- **Identity as a derived property** of project path or git remote — mismatch
  warnings, per-project overrides, `includeIf`-style match rules. All dropped
  when identity became the outer scope.
- **"Rewrite git config"** as a resolution for a config mismatch — mutates a
  file Wigwag doesn't own, cuts against git-native.
- **Initials as the identity signal** — same person every time.
- **Identity as an interactive breadcrumb segment beside the title** — always
  loses the rank contest with the title.
- **A status bar** carrying provenance — became the plain footer line.
- **Notes count chip** on the header button — read as a count of notes.
