# Handoff: Git-native Issue Tracker

## Overview
A portable, git-native issue tracker UI: a single JSONL file backs a table of issues with user-defined fields (text/select/multiselect), sourced from GitHub, Jira, or local entries, with per-issue comments and event history in a detail slide-over. Positioned as an alternative to GitHub Projects that works offline and merges cleanly in git.

## About the Design Files
The bundled HTML file is a **design reference built with a prototyping tool** (inline-styled React-like components, not production code). Treat it as a high-fidelity behavioral and visual spec. The task is to **recreate this UI in the target codebase's real stack** (React/Vue/etc., or your team's chosen framework if none exists yet), using the codebase's existing component/styling conventions — not to copy this HTML directly into production.

## Fidelity
**High-fidelity.** Colors, spacing, typography, and interaction details below are final; implement pixel-close using your codebase's design system/tokens where equivalent values exist.

## Screens / Views

### 1. Main table view
- **Purpose**: Browse, sort, reorder, filter, and inline-edit all issues.
- **Layout**: Header bar (app name + issue count + acting-as field + New tracker / Open file / Import & merge / Export buttons) → keyword filter input → a bordered, rounded (8px) card containing the table. Table is a flex-row-per-record layout (not `<table>`): a fixed 56px row-number/chevron column, a fixed 300px Title column, then N user-defined field columns (widths per field, see Design Tokens), then a fixed 44px trailing "+" add-field column.
- **Row height / padding**: fixed compact padding `7px 12px` for all cells (no density setting).
- **Row numbers**: the leftmost column shows the row's **display position** (1, 2, 3…), recomputed from current sort/filter order — not a persistent per-issue id. It stays stable while dragging rows but renumbers sequentially like a spreadsheet when the table re-sorts or filters.
- **Row hover**: background shifts to a very light blue-gray; a chevron-in-rounded-square button fades in over the row number (opacity driven by a CSS custom property `--reveal` set via the row's `:hover` style attribute) and opens an Open/Delete menu.
- **Comment indicator column**: a fixed 40px column immediately right of the Title column shows a chat-bubble icon; a small blue count badge appears when the issue has comments (tooltip previews the latest comment text). Clicking it opens the detail slide-over. This replaces having comments live only inside the detail view — it's a lightweight at-a-glance/entry point in the table itself.
- **Columns**: each header cell's **label area is a drag handle only** (`draggable`, grab cursor) — clicking the label text does *not* sort. A small sort-direction icon (↑/↓ stroke SVG) appears next to the label **only when that column is the active sort**; clicking the icon toggles/removes the sort. Dragging a column over another shows a **bold blue vertical insertion line** on the left or right edge of the target column (whichever half of the column the pointer is over) indicating exactly where the dragged column will land on drop.
- **Add field**: `+` button at the end of the header opens a popover with a hidden-fields "un-hide" list (if any), a field-name input, a type `<select>` (Text / Single-select / Multi-select — **no separate Reference type**), and an "Add field" submit button.
- **Add item**: a floating add-item bar sits **below the table card** (GitHub Projects style), not as a row inside it. Collapsed, it shows a `+` (aligned with the row-number column above) and a "You can use Control + Space to add an item" hint. Clicking anywhere on the bar turns it into a focused text input (blue border) whose left edge aligns with the Title column above. Enter or clicking `+` again creates a new row: if the typed text matches a GitHub issue URL it's fetched (same as pasting into a Title cell) and the row's Title becomes the fetched title; otherwise the typed text becomes the Title verbatim.

### 2. Cell types (rendered per field-column)
- **Source** (system field, not user-editable): a pill showing `GitHub #3298` / `Jira TRK-118` / `Local`.
- **Text**: clicking **anywhere in the cell** (not just on the text) starts editing — the input overlays the entire cell in place (2px blue border, no inset padding gap, small blue square "resize handle" glyph at the bottom-right corner for visual affordance, matching the reference), autofocus, Enter commits/blurs, Escape cancels. When **not editing** and the stored text matches a URL, a `owner/repo#123` GitHub-issue pattern, or a Jira-style key (e.g. `TRK-118`), it renders as a rounded-pill "reference chip" (blue text, 1px light border) instead of plain text, with an **↗ open-link icon** appended when a real URL/GitHub link is resolvable (clicking ↗ opens it in a new tab; clicking the rest of the chip re-enters edit mode). Plain (non-referenceable) text renders as ordinary truncating text, placeholder `—` when empty. **There is no separate "Reference" field type** — any text field auto-detects and "referencifies" its own content on display.
- **Single-select**: colored rounded-pill showing the current option (or a dashed-border `—` placeholder if unset), with a fixed-size **equilateral triangle "▼" arrow right-aligned to the cell's far edge** (not glued to the pill) — `border-left/right: 4px solid transparent; border-top: 7px solid oklch(0.6 0.006 250)` (7px tall regardless of content). Click opens a floating popover (below the cell, not clipped by table overflow) titled "Select an item" with a search/filter input and a scrollable option list; each option row shows a checkmark when selected, a colored ring/dot, and the label.
- **Multi-select**: same row layout — colored chips on the left, the same fixed equilateral triangle right-aligned on the far right edge of the cell. Chips that overflow the column width are **clipped, not wrapped** — row height stays uniform across the table (a deliberate homogenous-line-height choice, confirmed over letting chips wrap to a second line). Popover titled "Select items"; each row toggles membership (checkmark shown when selected).
- **Linked (Problem/Solution)**: system field. Shows a colored pill "Solution: <other issue title>" (blue) or "Problem: <other issue title>" (amber), truncated; click navigates to the linked issue's detail slide-over. Shows `—` when unlinked.

### 2a. Linked-value binding (per select/multiselect/text field)
Any select, multiselect, or text field can be configured to auto-derive its value from another field's linked GitHub/Jira issue, instead of (or replacing) manual entry:
- The column's `⋯` menu gets a **"Bound source"** dropdown listing the Title field plus every Issue-type field. Picking one sets that field's `linkedSourceId`.
- Below it, a rule textarea (enabled once a source is picked) takes a small JS-expression DSL referencing `source`, e.g. `source.github.labels.includes("bug") ? "Bug" : "Enhancement"` or, for a text field, `source.github.description`.
- `source.github` and `source.jira` are **always plain objects** (`{ labels: [], description: '' }` shape), never null — no null-guard needed in the rule even when the bound field isn't linked to anything.
- `source.isLinked` is `true` only when the bound field actually has GitHub/Jira metadata attached. The rule is only evaluated/applied when `isLinked` is true — unbound or not-yet-linked rows keep whatever value the user set manually (the rule's "else" branch must never clobber manual data).
- Select fields: the rule's return value is matched against the field's configured options (by id or case-insensitive label). Multiselect: same matching, but the rule returns an array (or single value) and each item is matched independently; non-matches are dropped. Text: the return value is coerced to a string and used directly.
- When a field is bound and its source is linked, the cell **locks** (small chain-link icon, no longer clickable to edit) both in the table and the detail slide-over.

### 3. Field editor modal (opened via column ⋯ → "Edit field…", select/multiselect only)
- Centered modal (340px wide, max 80vh, scrollable), dimmed full-screen overlay behind it (click to close).
- Field name input (bold, 14px).
- "OPTIONS — order sets sort order" list: each option row has ↑/↓ reorder controls (dimmed at ends), a color swatch square (click opens an 8-color palette picker inline below the row: red/amber/green/teal/blue/purple/pink/gray, selected swatch has a dark 2px ring), a label input, and a ✕ remove button.
- "New option…" input + "+" add button at the bottom, then a full-width "Done" button (blue, closes modal).

### 4. Detail slide-over
- **Purpose**: full-record view/edit for one issue, opened from the row chevron menu ("Open"), the comment-indicator column, or from a Linked-field chip.
- **Layout**: fixed panel, right-anchored, full viewport height, **87.5vw wide** (7/8 of the screen), over a dimmed overlay (click overlay or ✕ to close). The panel **slides in/out** via a `transform: translateX(...)` CSS transition (~280ms) rather than appearing instantly; the overlay fades its opacity in step with the panel's entrance. Opening sets the panel offscreen then triggers the transition on the next tick; closing reverses it and only unmounts the panel after the transition finishes.
- **Header**: a short monospace reference tag derived from the issue's persistent UUID (`#` + first 8 chars of `issue.uid`), **not** the row number — row numbers are positional/reorderable and unsuitable as a stable reference. Every issue gets a `uid` (a real UUID, `crypto.randomUUID()`) generated once at creation and persisted in the JSONL; this is what the short reference is derived from. Then the title (click-to-edit like table cells), ✕ close button top-right.
- **Fields section**: every visible column rendered as label (11px, uppercase-tracking, gray) + value, using **exactly the same cell markup/styling as the table** (text/reference chip, select pill+popover, multiselect chips+popover, linked pill, lock icon when bound+linked) — field UI is shared and reused between table and detail view, not reimplemented or restyled differently. Editing a cell here uses a separate edit/popover "context" from the table row's cells, so opening a popover in the slide-over does not also pop the same popover open in the (still-mounted, now-covered) table row behind it.
- **Activity section** ("ACTIVITY" label): comments and system history events are **merged into a single chronological timeline**, sorted **most-recent-first**. Comments show an avatar-initial dot (author's first letter, blue circle); history events show a small plain gray dot. Each entry shows `<b>actor</b> · time` then the text. The **add-comment composer sits at the top of the section** (above the list), matching where a newly posted comment will land given the most-recent-first order. "No activity yet." italic placeholder when both are empty.

## Interactions & Behavior
- **Inline text edit**: click anywhere in a text cell (full padded area, not just the text glyph) → an input overlays the whole cell in place (thick blue border, corner resize-handle square), autofocus, blur or Enter commits, Escape cancels — implemented per-cell via a single "active cell" (`{issueId, colId}`) + draft string in state, not per-cell local state.
- **Select/multiselect popovers**: single "active cell" concept also drives popover open/closed (only one open at a time across the whole table). Popovers are absolutely positioned relative to the cell (`position:absolute; top:calc(100% + Npx)`) with `z-index` high enough to float above table borders/overflow — the enclosing scroll container uses `overflow:visible` at the table-card level and `overflow-x:auto` only at the outer wrapper, so popovers aren't clipped.
- **Column drag-reorder**: native HTML5 drag events (`draggable`, `onDragStart` stores column id via `dataTransfer`, `onDragOver` prevents default, `onDrop` reorders an array of column ids).
- **Row menu**: chevron button toggles an Open/Delete menu; opening it also closes any active cell/popover (single "one overlay open at a time" pattern is used throughout — opening any menu/popover/edit closes the others).
- **Sorting**: click column label sorts asc, click again toggles desc; per-type sort value functions — select/multiselect sort by each option's configured order index (not alphabetically), text sorts alphabetically, linked sorts unlinked-last.
- **Reference auto-detection** (regex, run at display time only — the stored value is always plain text):
  - `^https?://...` → treated as a link; label = URL with the protocol stripped and truncated to 40 chars; opens in new tab via the ↗ icon.
  - `^owner/repo#123` (`[\w.-]+/[\w.-]+#\d+`) → treated as a GitHub issue reference; label = the original text; href synthesized as `https://github.com/<owner>/<repo>/issues/<num>`.
  - `^ABC-123` (`[A-Z][A-Z0-9]+-\d+`) → treated as a Jira key; label = original text; no href (Jira base URL unknown), so no ↗ icon.
  - Anything else renders as plain text.
- **Row hover reveal**: chevron/row-number crossfade uses a CSS custom property (`--reveal`) toggled by the row's hover style rather than JS state, so no re-render is needed on hover.
- **Filter**: keyword input filters rows by title substring match (case-insensitive), live as you type.
- **New field**: type is limited to Text / Single-select / Multi-select. (Text fields cover what would previously have been a separate "Reference" type — see below.)

## State Management
- All state lives in one component: `actingAs`, `exportMenuOpen`, `addFieldOpen` (+ new-field draft name/type), `addItemOpen`/`addItemDraft` (floating add-item bar), `filterQuery`, `sort {colId, dir}`, `columnOrder` (array of field ids, drives both rendering order and drag-reorder), `draggingColId`/`dragOverColId`/`dragOverSide` (drives the drag insertion-line indicator), `hiddenFieldIds`, `openColMenuId`, `fieldEditorColId` (+ its draft new-option label), `colorPickerOptIndex`, `activeCell {issueId, colId, ctx}` + `editDraft` (drives inline text edit AND select/multiselect popover-open state; `ctx` is `'row'` or `'panel'` so the table and the slide-over track edit/popover state independently even for the same issue+field), `optionFilterQuery` (popover search), `rowMenuIssueId`, `slideOverIssueId`, `slideOverVisible` (drives the slide-in/out transition), `newCommentDraft`.
- `fieldDefs`: a map of field id → `{ label, type: 'text'|'select'|'multiselect'|'source'|'linked', options?: [{id, label, color, emoji?}], linkedSourceId?: string|null, rule?: string }`. `linkedSourceId` + `rule` power the linked-value binding (see 2a above); `linkedSourceId` is the id of the Title field or another Issue-type field this field derives from. **Note the removed `'reference'` type** — text fields now cover that use case via display-time regex detection (see Interactions).
- `issues`: array of `{ id, uid, num, source: {kind, ref}, isLoadingTitle, values: {<fieldId>: value}, linkedIssueId, linkRole, comments: [], history: [] }`. `uid` is a real UUID generated once at row creation (`crypto.randomUUID()`) and is the durable identity used anywhere a stable per-issue reference is needed (e.g. the slide-over header); `num` is legacy/no longer shown in the UI and shouldn't be relied on for identity. Values for text fields are plain strings. Comments and history entries each carry a numeric `sortKey` (e.g. `Date.now()` for new entries) used to interleave and order the merged Activity timeline.
- Loading state: `isLoadingTitle` on an issue drives a shimmer "Loading…" placeholder in the Title cell (simulates an async GitHub/Jira title fetch).

## Design Tokens

### Colors (all `oklch()`, 8-color named palette — background / foreground / dot variants)
- red: bg `oklch(0.94 0.035 25)`, fg `oklch(0.42 0.16 25)`, dot `oklch(0.58 0.2 25)`
- amber: bg `oklch(0.95 0.045 85)`, fg `oklch(0.46 0.12 75)`, dot `oklch(0.78 0.15 85)`
- green: bg `oklch(0.94 0.05 150)`, fg `oklch(0.42 0.11 150)`, dot `oklch(0.6 0.15 150)`
- blue: bg `oklch(0.94 0.03 235)`, fg `oklch(0.42 0.13 235)`, dot `oklch(0.5 0.13 235)`
- teal: bg `oklch(0.94 0.035 195)`, fg `oklch(0.42 0.11 195)`, dot `oklch(0.55 0.11 195)`
- pink: bg `oklch(0.94 0.035 350)`, fg `oklch(0.45 0.14 350)`, dot `oklch(0.58 0.16 350)`
- purple: bg `oklch(0.94 0.04 300)`, fg `oklch(0.44 0.14 300)`, dot `oklch(0.56 0.14 300)`
- gray: bg `oklch(0.95 0.004 250)`, fg `oklch(0.42 0.006 250)`, dot `oklch(0.65 0.006 250)`
- Neutrals: page background `oklch(0.99 0.002 250)`, body text `oklch(0.2 0.005 250)`, borders `oklch(0.86–0.94 0.003 250)` (darker for header/table borders, lighter for cell dividers), muted/secondary text `oklch(0.5–0.65 0.006 250)`, placeholder text `oklch(0.75 0.006 250)`.
- Accent/primary action: `oklch(0.5 0.13 235)` (blue) — used for primary buttons, active input borders, links, sort-active state.
- Destructive: `oklch(0.55 0.18 25)` (red) — delete action text.

### Typography
- Font stack: `-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif`.
- App title: 22px / weight 700 / letter-spacing -0.01em.
- Table header labels: 11.5px / weight 600 / letter-spacing 0.02em, muted gray.
- Cell/body text: 12–13.5px regular; row titles 13px weight 600.
- Slide-over title: 17px / weight 700.
- Section labels (COMMENTS/HISTORY/OPTIONS/field labels): 11px / weight 600 / letter-spacing 0.04em, muted gray, uppercase in copy (not `text-transform` — typed uppercase).

### Spacing / shape
- Table card border-radius 8px; pills/chips fully rounded (`border-radius: 10–12px` for pills, up to 50% for small dots); modal/popover radius 8–10px.
- Column widths (px): row-number 56, title 300, add-field 44, source 128, reference/text-default 190, type 150, priority 118, linked 190, rag 150, teams 200, mitigation 190. Unlisted/custom fields default to 160.
- Select/multiselect down-arrow: fixed equilateral CSS triangle, `border-left/right: 4px solid transparent`, `border-top: 7px solid <gray-600>`, right-aligned flush to the cell's edge via `justify-content: space-between` on the cell's flex row (not glued next to the value pill).
- Shadows: popovers `0 8–14px 24–34px oklch(0/0.12–0.18)`; slide-over `-8px 0 32px oklch(0/0.14)`; field-editor modal `0 24px 60px oklch(0/0.28)`.

## Assets
No external images/icons — all glyphs are Unicode characters (▼, ⋯, ✓, ✕, ↑, ↓, ↩, ⚲, ↗) styled with color/size, no icon font or SVG library.

## Files
- `Issue Tracker.dc.html` — full prototype (markup + logic in one file; logic class starting at `class Component extends DCLogic`).
- `support.js` — prototyping-tool runtime shim; **not needed in the target codebase**, reference only if you need to see how bindings/loops resolved in the prototype.
