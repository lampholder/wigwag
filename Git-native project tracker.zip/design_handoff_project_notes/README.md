# Handoff: project notes, project comments & email pills

## Overview
Adds a **project-level (per-milestone) notes and comments surface** to the tracker, opened from a new **Notes** button on the header's metadata line. Notes are markdown, read-only until you click Edit. Any email address written in notes or comments renders as a person pill and links to `mailto:`.

Scope note: this handoff covers **only** these changes. The milestone switcher and the Wigwag logo were handed off separately and are unchanged here.

## About the Design Files
`Issue Tracker.dc.html` is a **design reference built with a prototyping tool** (inline-styled, React-like class component; `support.js` is its runtime shim and is **not** needed in your codebase). Reimplement in your own component conventions — don't port the prototype markup.

## Fidelity
**High-fidelity** for the notes/comments surface and the pill. Colours, sizes and the interaction model below are final.

---

## 1. The Notes button (header metadata line)

The metadata line under the milestone title becomes:

```
[glyph] Notes · 12 issues · format v0.1.0 · tracker.jsonl
```

- **Leftmost**, before the counts — it is an action, and leading position keeps it findable without competing with the milestone title above.
- **No background chip.** Deliberate: an earlier grey-pill version read as unbalanced noise on a line of plain grey metadata. It is text-weight UI — 12px, weight 500, `oklch(0.45 0.006 250)`, hover background `oklch(0.94 0.004 250)`, padding `1px 3px`, `margin-left:-3px` so the "Notes" glyph aligns flush left with the line's optical edge. When the panel is open the colour darkens to `oklch(0.35 0.006 250)`.
- A hair space (`&#8202;`) sits before the following `·` so spacing around every middot on the line is even (the button's 3px right padding supplies the rest).
- **Do not add a comment count** to this button. It was tried and removed — noisier than useful.
- Glyph: 11×11 document outline, `currentColor`, stroke-width 1.1.

## 2. The panel — reuse the issue slide-over

Project notes open in the **same slide-over used for issue details**, not a popover. An earlier popover version was rejected: this content is read at length, so it needs the panel.

Same anatomy and motion as the issue panel, verbatim:
- Overlay `oklch(0 0 0 / 0.28)`, `transition: background 0.28s ease`, `z-index:100`.
- Panel fixed right, `height:100vh; width:87.5vw`, `box-shadow:-8px 0 32px oklch(0 0 0 / 0.14)`, `z-index:101`, `transform: translateX(100%) → translateX(0)` on `0.28s cubic-bezier(0.2,0.8,0.2,1)`. Mount then flip visible on a 20ms timeout so the transform animates; on close, unmount 280ms after the transform starts.
- Header: monospace `project` eyebrow (12px, `oklch(0.55 0.006 250)`) over the **active milestone's name** (17px/700), with a ✕ at the right. Overlay click also closes.
- Sections below use the issue panel's eyebrow style: 11px, weight 600, letter-spacing 0.04em, `oklch(0.55 0.006 250)` — **NOTES** then **ACTIVITY**, separated by `1px solid oklch(0.92 0.003 250)`.
- Content columns capped at `max-width:760px` inside the wide panel.

## 3. Notes: markdown, read-only by default

- **Read mode** (default on open): rendered markdown. The whole body is a click target (`cursor:text`, hover `oklch(0.985 0.003 250)`, negative side margins so the hover bleeds to the padding edge) and there's an explicit **Edit** link in the section header (12px, weight 500, `oklch(0.5 0.13 235)`).
- **Edit mode**: monospace textarea, min-height 180px, 1px border in the accent blue, with **Cancel** / **Save** in the section header. ⌘/Ctrl-Enter saves, Escape cancels.
- **Closing the panel discards unsaved edits** — it does not silently commit. Only Save writes.
- Header also carries a quiet monospace `markdown` affordance label.
- Empty state, in read mode: italic "No notes yet — click to add."

**Markdown subset supported** (deliberately small — the source must stay diffable in git):
- `#`/`##`/`###` headings → 16/14/13px, weight 700, `oklch(0.25 0.008 250)`
- `- ` or `* ` bullets → a flex row with a `•` in `oklch(0.65 0.006 250)`
- inline `**bold**`, `\`code\`` (12px monospace on `oklch(0.95 0.004 250)`, radius 4, padding 1px 5px), and bare email addresses
- blank lines separate blocks; paragraph bottom margin 10px, bullets 4px, headings 6px

### Inline rendering gotcha (cost us two rounds — please keep)
Tokenised inline content **must not have whitespace between token elements**: indented markup puts a text node between every token, which collapses to a rendered space and detaches punctuation ("format v0.1.0 ." instead of "format v0.1.0."). Two mitigations, both applied:
1. the token loop is emitted with **no whitespace between sibling token elements**, and
2. the token container is `font-size:0` with **each token restating its own font-size** (the same trick as the header milestone pill).

Text tokens carry `white-space:pre-wrap` so their own real spaces survive. If your framework's JSX collapses whitespace differently this may be moot — verify with a string like `See \`tracker.jsonl\` for **format v0.1.0**.` and check there is no gap before the period.

## 4. Email pills

Any bare email address in **notes or comment bodies** renders as a pill:

- `display:inline-flex; align-items:center; gap:4px; padding:2px 7px; border-radius:10px`
- background `oklch(0.94 0.02 235)` → hover `oklch(0.91 0.03 235)`; text `oklch(0.42 0.13 235)`, weight 500, 13px
- `white-space:nowrap; vertical-align:baseline; text-decoration:none`
- leading 10×10 person glyph (circle head r=2.1 + shoulder arc, `currentColor`, stroke-width 1.2, `opacity:0.7`)
- **local part at full strength, domain at `opacity:0.6`** — scannable as a person, unambiguous as an address
- the element is an **`<a href="mailto:…">`**, `title="Email <address>"`

Two structural gotchas, both already fixed here:
1. **The local part and the dimmed domain must be ONE flex child** (wrap them in a single `<span>`), otherwise the pill's `gap:4px` lands *between* them and the address renders as "priya @lant.uk".
2. **The domain must end on an alphanumeric label** — `[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+`. A trailing `[A-Za-z0-9.-]+` greedily eats sentence-final periods, producing a pill reading "priya@lant.uk." that links to a non-existent address.

**Explicitly out of scope:** there is no user directory, no `@name` mentions, no autocomplete, and no per-comment identity record. All were prototyped and cut. An email is styled because it is an email — nothing is looked up.

## 5. Project comments (ACTIVITY)

Mirrors the issue panel's activity block: composer (input + blue **Post**, Enter posts) above the thread, newest appended last. Each entry is a 22px round blue avatar with the author's initial, `**author** · time` in 12px `oklch(0.5 0.006 250)`, then the body with email pills rendered. Empty state: italic "No project comments yet."

## 6. State & persistence

Per-milestone state, added to the existing milestone snapshot/restore:
- `projectNotes` (markdown string), `projectComments` (array of `{author, time, text}`)
- both are **included in the milestone snapshot** taken on switch, and **restored** with the target milestone; a newly created milestone starts with `projectNotes: ''` and `projectComments: []`
- transient, reset on milestone switch and never persisted: `projectNotesOpen`, `projectNotesVisible`, `projectNoteEditing`, `projectNoteDraft`, `projectCommentDraft`

For the real file format: notes and project comments are milestone-level, so they belong in the tracker file's milestone header/metadata record rather than in any issue row — keep the markdown as a plain string so diffs stay line-wise readable.

## Design tokens used
| Token | Use |
|---|---|
| `oklch(0.5 0.13 235)` | accent blue — Edit/Save, avatars, pill text base |
| `oklch(0.94 0.02 235)` / `oklch(0.91 0.03 235)` | pill background / hover |
| `oklch(0.42 0.13 235)` | pill text |
| `oklch(0.55 0.006 250)` | section eyebrows, metadata grey |
| `oklch(0.92 0.003 250)` | panel section dividers |
| `oklch(0.985 0.003 250)` | notes read-mode hover |
| `oklch(0.95 0.004 250)` | inline code background |

## Files
- `Issue Tracker.dc.html` — the prototype. The Notes button is on the metadata line under the milestone title; click it to open the panel.
- `support.js` — prototyping runtime shim; **not needed in your codebase.**
